<head>
    <!---linking style sheets----------------------------------------------------->
    <link href="change.php" rel="stylesheet">
</head>
<!-----------------------------hangman banner-------------------------------------->
<div id="banner">
    <!--title---------------------------------------------------------------------->
    <h1>Welcome to Hangman!</h1>
    <!--navigation bar links------------------------------------------------------->
    <div id="topnav">
        <a href="index.php">Home</a>
        <a href="game.php">Hangman-1 Player</a>
        <a href="game3.php">Hangman-2 Player</a>
        <a href="change.php">Settings</a>
        <a href="credits.php">Credits</a>
    </div>
</div>